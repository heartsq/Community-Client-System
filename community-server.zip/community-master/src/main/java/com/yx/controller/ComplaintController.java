package com.yx.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.pagehelper.PageInfo;
import com.sun.org.apache.xml.internal.serializer.Method;
import com.yx.model.Complaint;
import com.yx.service.IComplaintService;
import com.yx.service.IOwnerService;
import com.yx.util.JsonObject;
import com.yx.util.R;
import com.yx.model.Owner;
import com.yx.model.Userinfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.endpoint.dynamic.DynamicClientFactory;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 */
@Api(tags = {""})
@RestController
@RequestMapping("/complaint")
public class ComplaintController {

    private Logger log = LoggerFactory.getLogger(getClass());

    @Resource
    private IComplaintService complaintService;
    @Resource
    private IOwnerService ownerService;

    @RequestMapping("/queryComplaintAll")
    public JsonObject queryComplaintAll(Complaint complaint, @RequestParam(defaultValue = "1") Integer page,
                                        @RequestParam(defaultValue = "15") Integer limit) throws Exception {
/*
        DynamicClientFactory clientFactory = DynamicClientFactory.newInstance();
        Client client = clientFactory.createClient("http://localhost:8888/ws/complaint?wsdl");
        PageInfo<Complaint> pageInfo = new PageInfo<>();
        pageInfo=null;
        //byte[] byteArray=serializeComplaint(complaint);
        //Complaint c=deserializeComplaint(byteArray);
       //System.out.println("序列化为byteArray"+byteArray);
        //System.out.println("反序列化为c"+c);

        try
        {
            Object[] objects = client.invoke("findComplaintAll", new Object[]{page, limit, complaint});
            if(objects != null){
                pageInfo.setTotal((Long) objects[0]);  // 第一个元素为总记录数
                pageInfo.setList((List<Complaint>) objects[1]);  // 第二个元素为当前页的 Complaint 列表
            }
        }catch (Exception e) {
            e.printStackTrace();
        }

        JsonObject jsonObject = new JsonObject(0, "ok", pageInfo.getTotal(), pageInfo.getList());
        // 返回响应对象
        return jsonObject;*/

        PageInfo<Complaint> pageInfo=complaintService.findComplaintAll(page,limit,complaint);
        return new JsonObject(0,"ok",pageInfo.getTotal(),pageInfo.getList());

    }

    @RequestMapping("/queryComplaintAll2")
    public JsonObject queryComplaintAll2(Complaint complaint, HttpServletRequest request,
                                        @RequestParam(defaultValue = "1") Integer page,
                                        @RequestParam(defaultValue = "15") Integer limit) throws Exception {
      //获取当前得登录用户
        Userinfo userinfo= (Userinfo) request.getSession().getAttribute("user");
        String username=userinfo.getUsername();
        //根据username获取登录账号得业主id
        Owner owner=ownerService.queryOwnerByName(username);
        complaint.setOwnerId(owner.getId());
        //byte[] byteArray=serializeComplaint(complaint);
        PageInfo<Complaint> pageInfo=complaintService.findComplaintAll(page,limit,complaint);
        return new JsonObject(0,"ok",pageInfo.getTotal(),pageInfo.getList());
        /*DynamicClientFactory clientFactory = DynamicClientFactory.newInstance();
        Client client = clientFactory.createClient("http://localhost:8888/ws/complaint?wsdl");

        Userinfo userinfo= (Userinfo) request.getSession().getAttribute("user");
        String username=userinfo.getUsername();

        Object[] result2 = client.invoke("queryOwnerByName", username);
        Owner owner = (Owner) result2[0];
        complaint.setOwnerId(owner.getId());

        Object[] result3 = client.invoke("findComplaintAll", page, limit, complaint);
        PageInfo<Complaint> pageInfo = (PageInfo<Complaint>) result3[0];

        JsonObject jsonObject = new JsonObject(0, "ok", pageInfo.getTotal(), pageInfo.getList());
        return jsonObject;*/
    }



    @ApiOperation(value = "新增")
    @RequestMapping("/add")
    public R add(@RequestBody Complaint complaint,HttpServletRequest request) throws Exception {
      //获取当前得登录用户
        Userinfo userinfo= (Userinfo) request.getSession().getAttribute("user");
        String username=userinfo.getUsername();
        //根据username获取登录账号得业主id
        Owner owner=ownerService.queryOwnerByName(username);
        complaint.setOwnerId(owner.getId());
        complaint.setStatus(0);
        complaint.setComDate(new Date());
        int num=complaintService.add(complaint);
        if(num>0){
            return  R.ok();
        }
        return R.fail("失败啦");
        /*DynamicClientFactory clientFactory = DynamicClientFactory.newInstance();
        Client client = clientFactory.createClient("http://localhost:8888/ws/complaint?wsdl");

        Userinfo userinfo= (Userinfo) request.getSession().getAttribute("user");
        String username=userinfo.getUsername();

        Object[] result2 = client.invoke("queryOwnerByName", username);
        Owner owner = (Owner) result2[0];
        complaint.setOwnerId(owner.getId());
        complaint.setStatus(0);
        complaint.setComDate(new Date());

        Object[] result3 = client.invoke("add", complaint);
        int num = (int) result3[0];

        if (num > 0) {
            return R.ok();
        } else {
            return R.fail("失败啦");
        }*/
    }

    @ApiOperation(value = "删除")
    @RequestMapping("/deleteByIds")
    public R deleteByIds(String ids) throws Exception {

       List<String> list=Arrays.asList(ids.split(","));
       for(String id:list){
           complaintService.delete(Long.parseLong(id));
       }
       return R.ok();
        /*
        DynamicClientFactory clientFactory = DynamicClientFactory.newInstance();
        Client client = clientFactory.createClient("http://localhost:8888/ws/complaint?wsdl");

        List<String> list = Arrays.asList(ids.split(","));
        for (String id : list) {
            Object[] result = client.invoke("delete", Long.parseLong(id));
            int num = (int) result[0];
        }

        return R.ok();*/
    }

    @ApiOperation(value = "更新")
    @RequestMapping("/update")
    public R update(Integer id) throws Exception {
        Complaint complaint=new Complaint();
        complaint.setId(id);
        complaint.setStatus(1);
//         complaint.setClr()
        int num= complaintService.updateData(complaint);
        if(num>0){
            return R.ok();
        }else{
            return R.fail("处理失败");
        }
        /*
        DynamicClientFactory clientFactory = DynamicClientFactory.newInstance();
        Client client = clientFactory.createClient("http://localhost:8888/ws/complaint?wsdl");

        Complaint complaint = new Complaint();
        complaint.setId(id);
        complaint.setStatus(1);

        Object[] result = client.invoke("updateData", complaint);
        int num = (int) result[0];

        if (num > 0) {
            return R.ok();
        } else {
            return R.fail("处理失败");
        }*/
    }

    @ApiOperation(value = "查询分页数据")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "page", value = "页码"),
        @ApiImplicitParam(name = "pageCount", value = "每页条数")
    })
    @GetMapping()
    public Page<Complaint> findListByPage(@RequestParam Integer page,
                                          @RequestParam Integer pageCount) throws Exception {

        return complaintService.findListByPage(page, pageCount);
    }

    @ApiOperation(value = "id查询")
    @GetMapping("{id}")
    public Complaint findById(@PathVariable Long id) throws Exception {
        DynamicClientFactory clientFactory = DynamicClientFactory.newInstance();
        Client client = clientFactory.createClient("http://localhost:8888/ws/complaint?wsdl");
        Object[] result = client.invoke("findById", id);
        return complaintService.findById(id);
    }
}
