@javax.xml.bind.annotation.XmlSchema(
        attributeFormDefault=javax.xml.bind.annotation.XmlNsForm.QUALIFIED,
        elementFormDefault=javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.yx.dao;
