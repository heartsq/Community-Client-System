package com.yx.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yx.model.ComplaintType;
import org.springframework.stereotype.Component;

/**
 * <p>
 *  Mapper 接口
 * </p>
 */
@Component("ComplaintTypeDao")
public interface ComplaintTypeMapper extends BaseMapper<ComplaintType> {

}
