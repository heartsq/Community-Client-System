package com.yx.model;

import lombok.Data;

@Data
public class Tongji {

    private String name;
    private String counts;

}
