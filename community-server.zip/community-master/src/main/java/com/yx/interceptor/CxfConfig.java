package com.yx.interceptor;

import com.yx.service.impl.*;
import org.apache.cxf.Bus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

import javax.xml.ws.Endpoint;

/**
 * description: CXF 配置 服务小于三个可以这样配置，多了的话参考
 *
 * @param
 * @return String
 * @author:jinshengyuan
 * @date: 2022-1-30
 */
//@Configuration
public class CxfConfig {
    @Autowired
    private Bus bus;

    @Autowired
    private UserinfoServiceImpl userService;

    @Autowired
    private ComplaintServiceImpl complaintService;

    @Autowired
    private ComplaintTypeServiceImpl complainttypeService;

    @Autowired
    private BuildingServiceImpl buildingService;

    @Autowired
    private CarchargeServiceImpl carchargeService;

    @Autowired
    private ClockInNewServiceImpl clockInNewService;

    @Autowired
    private ClockinServiceImpl clockInService;

    @Autowired
    private HouseServiceImpl houseService;

    @Autowired
    private OwnerServiceImpl ownerService;

    @Autowired
    private ParkingServiceImpl parkingService;

    @Autowired
    private PropertyInfoServiceImpl propertyInfoService;

    @Autowired
    private PropertyTypeServiceImpl propertyTypeService;

    @Autowired
    private RecordsServiceImpl recordsService;

    @Autowired
    private RepairServiceImpl repairService;

    @Autowired
    private RepairtypeServiceImpl repairTypeService;

    /**
     * description: hello webService服务
     *
     * @param
     * @return String
     * @author:jinshengyuan
     * @date: 2022-1-30
     */

    @Bean
    public Endpoint userInfo() {
        EndpointImpl endpoint = new EndpointImpl(bus, userService);
        endpoint.publish("/userInfo");
        return endpoint;
    }

    @Bean
    public Endpoint complaint() {
        EndpointImpl endpoint = new EndpointImpl(bus, complaintService);
        endpoint.publish("/complaint");
        return endpoint;
    }

    @Bean
    public Endpoint complainttype() {
        EndpointImpl endpoint = new EndpointImpl(bus, complainttypeService);
        endpoint.publish("/complainttype");
        return endpoint;
    }

    @Bean
    public Endpoint building() {
        EndpointImpl endpoint = new EndpointImpl(bus, buildingService);
        endpoint.publish("/building");
        return endpoint;
    }

    @Bean
    public Endpoint carcharge() {
        EndpointImpl endpoint = new EndpointImpl(bus, carchargeService);
        endpoint.publish("/carcharge");
        return endpoint;
    }

    @Bean
    public Endpoint clockInNew() {
        EndpointImpl endpoint = new EndpointImpl(bus, clockInNewService);
        endpoint.publish("/clockinnew");
        return endpoint;
    }

    @Bean
    public Endpoint clockIn() {
        EndpointImpl endpoint = new EndpointImpl(bus, clockInService);
        endpoint.publish("/clockin");
        return endpoint;
    }

    @Bean
    public Endpoint house() {
        EndpointImpl endpoint = new EndpointImpl(bus, houseService);
        endpoint.publish("/house");
        return endpoint;
    }

    @Bean
    public Endpoint owner() {
        EndpointImpl endpoint = new EndpointImpl(bus, ownerService);
        endpoint.publish("/owner");
        return endpoint;
    }

    @Bean
    public Endpoint parking() {
        EndpointImpl endpoint = new EndpointImpl(bus, parkingService);
        endpoint.publish("/parking");
        return endpoint;
    }

    @Bean
    public Endpoint propertyInfo() {
        EndpointImpl endpoint = new EndpointImpl(bus, propertyInfoService);
        endpoint.publish("/propertyinfo");
        return endpoint;
    }

    @Bean
    public Endpoint propertytype() {
        EndpointImpl endpoint = new EndpointImpl(bus, propertyTypeService);
        endpoint.publish("/propertytype");
        return endpoint;
    }

    @Bean
    public Endpoint records() {
        EndpointImpl endpoint = new EndpointImpl(bus, recordsService);
        endpoint.publish("/records");
        return endpoint;
    }


    @Bean
    public Endpoint repair() {
        EndpointImpl endpoint = new EndpointImpl(bus, repairService);
        endpoint.publish("/repair");
        return endpoint;
    }

    @Bean
    public Endpoint repairtype() {
        EndpointImpl endpoint = new EndpointImpl(bus, repairTypeService);
        endpoint.publish("/repairtype");
        return endpoint;
    }

    /*

    @Autowired
    private RepairtypeServiceImpl repairTypeService;*/



}
