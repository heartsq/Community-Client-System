package com.yx.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.HouseMapper;
import com.yx.model.House;
import com.yx.service.IHouseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 */
@AutoPublishWS(publishPath = "/house")
@WebService
@Service
public class HouseServiceImpl implements IHouseService {
    @Autowired
    private HouseMapper houseDao;

    @WebMethod
    @WebResult(name = "a")
    @Override
    public PageInfo<House> findHouseAll(@WebParam(name = "page")int page, @WebParam(name = "pagesize")int pagesize, @WebParam(name = "numbers")String numbers) {
        PageHelper.startPage(page,pagesize);
        List<House> list=houseDao.findHouseAll(numbers);
        PageInfo<House> pageInfo=new PageInfo<>(list);
        return pageInfo;
    }

    @WebMethod
    @WebResult(name = "b")
    @Override
    public List<House> findList() {
        return houseDao.selectList(null);
    }

    @WebMethod
    @WebResult(name = "c")
    @Override
    public Page<House> findListByPage(@WebParam(name = "page")Integer page, @WebParam(name = "pageCount")Integer pageCount){
        Page<House> wherePage = new Page<>(page, pageCount);
        House where = new House();

        return   houseDao.selectPage(wherePage, Wrappers.query(where));
    }

    @WebMethod
    @WebResult(name = "d")
    @Override
    public int add(@WebParam(name = "house")House house){
        return houseDao.insert(house);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return houseDao.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public int updateData(@WebParam(name = "house")House house){
        return houseDao.updateById(house);
    }

    @WebMethod
    @WebResult(name = "g")
    @Override
    public House findById(@WebParam(name = "id")Long id){
        return  houseDao.selectById(id);
    }

    @WebMethod
    @WebResult(name = "h")
    @Override
    public House queryHouseById(@WebParam(name = "houId")Integer houId) {
        return houseDao.queryHouseById(houId);
    }
}
