package com.yx.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.UserinfoMapper;
import com.yx.model.Userinfo;
import com.yx.service.IUserinfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 */

/*
@AutoPublishWS(publishPath = "/userinfo")
@WebService(endpointInterface = "com.yx.service.IUserinfoService")
@WebService*/
@AutoPublishWS(publishPath = "/userinfo")
@WebService
@Service
public class UserinfoServiceImpl  implements IUserinfoService {
    @Autowired
    private UserinfoMapper userinfoMapper;

    @WebMethod
    @WebResult(name = "a")
    @Override
    public Page<Userinfo> findListByPage(@WebParam(name = "page")Integer page, @WebParam(name = "pageCount")Integer pageCount){
        Page<Userinfo> wherePage = new Page<>(page, pageCount);
        Userinfo where = new Userinfo();

        return   userinfoMapper.selectPage(wherePage, Wrappers.query(where));
    }


    @WebMethod
    @WebResult(name = "b")
    @Override
    public PageInfo<Userinfo> findUserinfoAll(@WebParam(name = "page")int page, @WebParam(name = "pageSize")int pageSize, @WebParam(name = "userinfo")Userinfo userinfo) {
        PageHelper.startPage(page,pageSize);
        //查询的结果集
        List<Userinfo> list=userinfoMapper.queryUserinfoAll(userinfo);
        PageInfo<Userinfo> pageInfo=new PageInfo<>(list);
        return pageInfo;
    }

    @WebMethod
    @WebResult(name = "c")
    @Override
    public int add(@WebParam(name = "userinfo")Userinfo userinfo){
        return userinfoMapper.insert(userinfo);
    }

    @WebMethod
    @WebResult(name = "d")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return userinfoMapper.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int updateData(@WebParam(name = "userinfo")Userinfo userinfo){
        return userinfoMapper.updateById(userinfo);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public Userinfo findById(@WebParam(name = "id")Long id){
        return  userinfoMapper.selectById(id);
    }

    @WebMethod
    @WebResult(name = "g")
    @Override
    public Userinfo queryUserByNameAndPwd(@WebParam(name = "userinfo")Userinfo userinfo) {
        return userinfoMapper.queryUserByNameAndPwd(userinfo);
    }

    @WebMethod
    @WebResult(name = "h")
    @Override
    public void deleteUserByUsername(@WebParam(name = "=username")String username) {
        userinfoMapper.deleteUserByUsername(username);
    }
}
