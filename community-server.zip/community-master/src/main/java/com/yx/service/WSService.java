package com.yx.service;

public interface WSService {
    String sayHello(String name);
    String getInfo();
}
