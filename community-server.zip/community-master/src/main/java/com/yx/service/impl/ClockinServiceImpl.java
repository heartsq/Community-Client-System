package com.yx.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.ClockinMapper;
import com.yx.model.Clockin;
import com.yx.service.IClockinService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.Date;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 */
@AutoPublishWS(publishPath = "/clockin")
@WebService
@Service
public class ClockinServiceImpl implements IClockinService {

    @Autowired
    private ClockinMapper clockinDao;

    @WebMethod
    @WebResult(name = "a")
    @Override
    public PageInfo<Clockin> queryClockInAll(@WebParam(name = "pageNum")int pageNum, @WebParam(name = "pageSize")int pageSize, @WebParam(name = "clockin")Clockin clockin) {
        PageHelper.startPage(pageNum,pageSize);
        List<Clockin> list = clockinDao.queryClockInAll(clockin);
        return new PageInfo<>(list);
    }

    @WebMethod
    @WebResult(name = "b")
    @Override
    public Page<Clockin> findListByPage(@WebParam(name = "page")Integer page, @WebParam(name = "pageCount")Integer pageCount){
        Page<Clockin> wherePage = new Page<>(page, pageCount);
        Clockin where = new Clockin();

        return   clockinDao.selectPage(wherePage, Wrappers.query(where));
    }

    @WebMethod
    @WebResult(name = "c")
    @Override
    public int add(@WebParam(name = "clockin")Clockin clockin){
        return clockinDao.insert(clockin);
    }

    @WebMethod
    @WebResult(name = "d")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return clockinDao.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int updateData(@WebParam(name = "clockin")Clockin clockin){
        return clockinDao.updateById(clockin);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public Clockin findById(@WebParam(name = "id")Long id){
        return  clockinDao.selectById(id);
    }

    @WebMethod
    @WebResult(name = "g")
    @Override
    public Date queryCountByOwnIdAndTime(@WebParam(name = "ownId")Integer ownId) {
        return clockinDao.queryCountByOwnIdAndTime(ownId);
    }
}
