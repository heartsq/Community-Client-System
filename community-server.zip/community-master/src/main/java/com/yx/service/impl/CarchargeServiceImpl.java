package com.yx.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.CarchargeMapper;
import com.yx.model.Carcharge;
import com.yx.service.ICarchargeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 */
@AutoPublishWS(publishPath = "/carcharge")
@WebService
@Service
public class CarchargeServiceImpl implements ICarchargeService {

    @Autowired
    private CarchargeMapper carchargeDao;

    @WebMethod
    @WebResult(name = "a")
    @Override
    public PageInfo<Carcharge> findCarchargeAll(@WebParam(name = "page")int page, @WebParam(name = "pagesize")int pagesize, @WebParam(name = "carcharge")Carcharge carcharge) {
        PageHelper.startPage(page,pagesize);
        List<Carcharge> list=carchargeDao.queryCarChargeAll(carcharge);
        PageInfo<Carcharge> pageInfo=new PageInfo(list);
        return pageInfo;
    }

    @WebMethod
    @WebResult(name = "b")
    @Override
    public Page<Carcharge> findListByPage(@WebParam(name = "page")Integer page, @WebParam(name = "pageCount")Integer pageCount){
        Page<Carcharge> wherePage = new Page<>(page, pageCount);
        Carcharge where = new Carcharge();

        return   carchargeDao.selectPage(wherePage, Wrappers.query(where));
    }

    @WebMethod
    @WebResult(name = "c")
    @Override
    public int add(@WebParam(name = "carcharge")Carcharge carcharge){
        return carchargeDao.insert(carcharge);
    }

    @WebMethod
    @WebResult(name = "d")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return carchargeDao.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int updateData(@WebParam(name = "carcharge")Carcharge carcharge){
        return carchargeDao.updateById(carcharge);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public Carcharge findById(@WebParam(name = "id")Long id){
        return  carchargeDao.selectById(id);
    }
}
