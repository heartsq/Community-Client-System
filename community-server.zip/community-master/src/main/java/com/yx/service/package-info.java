@javax.xml.bind.annotation.XmlSchema(//namespace = "http://dao.demo",
        attributeFormDefault=javax.xml.bind.annotation.XmlNsForm.QUALIFIED,
        elementFormDefault=javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.yx.service;
