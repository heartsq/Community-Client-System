package com.yx.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.OwnerMapper;
import com.yx.model.Owner;
import com.yx.service.IOwnerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 */
@AutoPublishWS(publishPath = "/owner")
@WebService
@Service
public class OwnerServiceImpl implements IOwnerService {

    @Autowired
    private OwnerMapper ownerDao;

    @WebMethod
    @WebResult(name = "a")
    @Override
    public PageInfo<Owner> findOwnerAll(@WebParam(name = "page")int page, @WebParam(name = "pagesize")int pagesize, @WebParam(name = "owner")Owner owner) {
        PageHelper.startPage(page,pagesize);
        List<Owner> list=ownerDao.queryOwnerAll(owner);
        PageInfo<Owner> pageInfo=new PageInfo<>(list);
        return pageInfo;
    }

    @WebMethod
    @WebResult(name = "b")
    @Override
    public Page<Owner> findListByPage(@WebParam(name = "page")Integer page, @WebParam(name = "pageCount")Integer pageCount){
        Page<Owner> wherePage = new Page<>(page, pageCount);
        Owner where = new Owner();

        return   ownerDao.selectPage(wherePage, Wrappers.query(where));
    }

    @WebMethod
    @WebResult(name = "c")
    @Override
    public Owner queryOwnerByName(@WebParam(name = "username")String username) {
        return ownerDao.queryOwnerByName(username);
    }

    @WebMethod
    @WebResult(name = "d")
    @Override
    public int add(@WebParam(name = "owner")Owner owner){
        return ownerDao.insert(owner);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return ownerDao.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public int updateData(@WebParam(name = "owner")Owner owner){
        return ownerDao.updateById(owner);
    }

    @WebMethod
    @WebResult(name = "g")
    @Override
    public Owner findById(@WebParam(name = "id")Long id){
        return  ownerDao.selectById(id);
    }

    @WebMethod
    @WebResult(name = "h")
    @Override
    public void deleteOwnerUserByUserName(@WebParam(name = "username")String username) {
        ownerDao.deleteOwnerUserByUserName(username);
    }

    @WebMethod
    @WebResult(name = "i")
    @Override
    public Owner queryOwnerById(@WebParam(name = "parseLong")long parseLong) {
        return ownerDao.queryOwnerById(parseLong);
    }
}
