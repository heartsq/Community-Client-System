package com.yx.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.PropertyInfoMapper;
import com.yx.model.PropertyInfo;
import com.yx.service.IPropertyInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 */
@AutoPublishWS(publishPath = "/propertyinfo")
@WebService
@Service
public class PropertyInfoServiceImpl implements IPropertyInfoService {

    @Autowired
    private PropertyInfoMapper propertyInfoDao;

    @WebMethod
    @WebResult(name = "a")
    @Override
    public PageInfo<PropertyInfo> findPropertyInfoAll(@WebParam(name = "page")int page, @WebParam(name = "pagesize")int pagesise,
                                                      @WebParam(name = "propertyInfo")PropertyInfo propertyInfo) {
        PageHelper.startPage(page,pagesise);
        List<PropertyInfo> list=propertyInfoDao.queryListAll(propertyInfo);
        return new PageInfo(list);
    }

    @WebMethod
    @WebResult(name = "b")
    @Override
    public void deleteInfoByHouIdAndTime(@WebParam(name = "houId")Integer houId, @WebParam(name = "endTime")Date endTime) {

         SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
         String dateString = formatter.format(endTime);
         dateString=dateString.substring(0,9);
         propertyInfoDao.deleteByHouIdAndTime(houId,dateString);
    }

    @WebMethod
    @WebResult(name = "c")
    @Override
    public Page<PropertyInfo> findListByPage(@WebParam(name = "page")Integer page, @WebParam(name = "pageCount")Integer pageCount){
        Page<PropertyInfo> wherePage = new Page<>(page, pageCount);
        PropertyInfo where = new PropertyInfo();

        return   propertyInfoDao.selectPage(wherePage, Wrappers.query(where));
    }

    @WebMethod
    @WebResult(name = "d")
    @Override
    public int add(@WebParam(name = "propertyInfo")PropertyInfo propertyInfo){
        return propertyInfoDao.insert(propertyInfo);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return propertyInfoDao.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public int updateData(@WebParam(name = "propertyInfo")PropertyInfo propertyInfo){
        return propertyInfoDao.updateById(propertyInfo);
    }

    @WebMethod
    @WebResult(name = "g")
    @Override
    public PropertyInfo findById(@WebParam(name = "id")Long id){
        return  propertyInfoDao.selectById(id);
    }
}
