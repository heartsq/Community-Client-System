package com.yx.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.RepairMapper;
import com.yx.model.Repair;
import com.yx.model.Tongji;
import com.yx.service.IRepairService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kappy
 * @since 2020-10-28
 */
@AutoPublishWS(publishPath = "/repair")
@WebService
@Service
public class RepairServiceImpl implements IRepairService {

    @Autowired
    private RepairMapper repairDao;

    @WebMethod
    @WebResult(name = "a")
    @Override
    public PageInfo<Repair> findRepairAll(@WebParam(name = "page")int page, @WebParam(name = "pagesize")int pagesize, @WebParam(name = "repair")Repair repair) {
        PageHelper.startPage(page,pagesize);
        List<Repair> list=repairDao.queryRepairAll(repair);
        PageInfo<Repair> pageInfo=new PageInfo(list);
        return pageInfo;
    }

    @WebMethod
    @WebResult(name = "b")
    @Override
    public List<Repair> queryList() {
        return repairDao.queryRepairAll(null);
    }

    @WebMethod
    @WebResult(name = "c")
    @Override
    public Page<Repair> findListByPage(@WebParam(name = "page")Integer page, @WebParam(name = "pageCount")Integer pageCount){
        Page<Repair> wherePage = new Page<>(page, pageCount);
        Repair where = new Repair();

        return   repairDao.selectPage(wherePage, Wrappers.query(where));
    }

    @WebMethod
    @WebResult(name = "d")
    @Override
    public int add(@WebParam(name = "repair")Repair repair){
        return repairDao.insert(repair);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return repairDao.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public int updateData(@WebParam(name = "repair")Repair repair){
        return repairDao.updateById(repair);
    }

    @WebMethod
    @WebResult(name = "g")
    @Override
    public Repair findById(@WebParam(name = "id")Long id){
        return  repairDao.selectById(id);
    }

    @WebMethod
    @WebResult(name = "h")
    @Override
    public List<Tongji> queryTongji() {
        return repairDao.queryTongji();
    }
}
