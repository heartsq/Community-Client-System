package com.yx.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.ComplaintMapper;
import com.yx.model.Complaint;
import com.yx.service.IComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 */
@AutoPublishWS(publishPath = "/complaint")
@WebService
@Service
public class ComplaintServiceImpl implements IComplaintService {

    @Autowired
    private ComplaintMapper complaintDao;

    @WebMethod
    @WebResult(name = "a")
    @Override
    public PageInfo<Complaint> findComplaintAll(
            @WebParam(name = "page")int page, @WebParam(name = "pagesize")int pagesize, @WebParam(name = "complaint")Complaint complaint) throws IOException, ClassNotFoundException {
        PageHelper.startPage(page,pagesize);
        List<Complaint> list=complaintDao.queryComplaintAll(complaint);
        PageInfo<Complaint> pageInfo=new PageInfo(list);
        return pageInfo;
    }

    @WebMethod
    @WebResult(name = "b")
    @Override
    public Page<Complaint> findListByPage(@WebParam(name = "page")Integer page, @WebParam(name = "pageCount")Integer pageCount){
        Page<Complaint> wherePage = new Page<>(page, pageCount);
        Complaint where = new Complaint();
        return   complaintDao.selectPage(wherePage, Wrappers.query(where));
    }


    @WebMethod
    @WebResult(name = "c")
    @Override
    public int add(@WebParam(name = "complaint")Complaint complaint){
        return complaintDao.insert(complaint);
    }

    @WebMethod
    @WebResult(name = "d")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return complaintDao.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int updateData(@WebParam(name = "complaint")Complaint complaint){
        return complaintDao.updateById(complaint);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public Complaint findById(@WebParam(name = "id")Long id){
        return  complaintDao.selectById(id);
    }
}
