package com.yx.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.RepairMapper;
import com.yx.dao.RepairtypeMapper;
import com.yx.model.Repairtype;
import com.yx.service.IRepairtypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 */
@AutoPublishWS(publishPath = "/repairtype")
@WebService
@Service
public class RepairtypeServiceImpl implements IRepairtypeService {

    @Autowired
    private RepairtypeMapper repairtypeDao;


    @WebMethod
    @WebResult(name = "a")
    @Override
    public Page<Repairtype> findListByPage(@WebParam(name = "page")Integer page, @WebParam(name = "pageCount")Integer pageCount){
        Page<Repairtype> wherePage = new Page<>(page, pageCount);
        Repairtype where = new Repairtype();

        return   repairtypeDao.selectPage(wherePage, Wrappers.query(where));
    }

    @WebMethod
    @WebResult(name = "b")
    @Override
    public List<Repairtype> findList() {
        return   repairtypeDao.selectList(null);
    }

    @WebMethod
    @WebResult(name = "c")
    @Override
    public int add(@WebParam(name = "repairtype")Repairtype repairtype){
        return repairtypeDao.insert(repairtype);
    }

    @WebMethod
    @WebResult(name = "d")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return repairtypeDao.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int updateData(@WebParam(name = "repairtype")Repairtype repairtype){
        return repairtypeDao.updateById(repairtype);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public Repairtype findById(@WebParam(name = "id")Long id){
        return  repairtypeDao.selectById(id);
    }
}
