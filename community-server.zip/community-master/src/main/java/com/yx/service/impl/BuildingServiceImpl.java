package com.yx.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.BuildingMapper;
import com.yx.model.Building;
import com.yx.service.IBuildingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 */
@AutoPublishWS(publishPath = "/building")
@WebService
@Service
public class BuildingServiceImpl implements IBuildingService {

    @Autowired
    private BuildingMapper buildingDao;

    @WebMethod
    @WebResult(name = "a")
    @Override
    public PageInfo<Building> findBuildAll(@WebParam(name = "page")int page, @WebParam(name = "pageSize")int pageSize, @WebParam(name = "numbers")String numbers) {
        PageHelper.startPage(page,pageSize);
        List<Building> list=buildingDao.queryBuildAll(numbers);
        return new PageInfo<>(list);
    }

    @WebMethod
    @WebResult(name = "b")
    @Override
    public Page<Building> findListByPage(@WebParam(name = "page")Integer page, @WebParam(name = "pageCount")Integer pageCount){
        Page<Building> wherePage = new Page<>(page, pageCount);
        Building where = new Building();

        return   buildingDao.selectPage(wherePage, Wrappers.query(where));
    }

    @WebMethod
    @WebResult(name = "c")
    @Override
    public int add(@WebParam(name = "building")Building building){
        return buildingDao.insert(building);
    }

    @WebMethod
    @WebResult(name = "d")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return buildingDao.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int updateData(@WebParam(name = "building")Building building){
        return buildingDao.updateById(building);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public Building findById(@WebParam(name = "id")Long id){
        return  buildingDao.selectById(id);
    }

    @WebMethod
    @WebResult(name = "g")
    @Override
    public Building queryBuildById(@WebParam(name = "buildId")Integer buildId) {
        return buildingDao.queryBuildById(buildId);
    }
}
