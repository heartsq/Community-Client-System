package com.yx.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.ComplaintTypeMapper;
import com.yx.dao.UserinfoMapper;
import com.yx.model.ComplaintType;
import com.yx.service.IComplaintTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 */
@AutoPublishWS(publishPath = "/complainttype")
@WebService
@Service
public class ComplaintTypeServiceImpl implements IComplaintTypeService {

    @Autowired
    private ComplaintTypeMapper complaintTypeMapper;

    @WebMethod
    @WebResult(name = "a")
    @Override
    public Page<ComplaintType> findListByPage(@WebParam(name = "page")Integer page, @WebParam(name = "pageCount")Integer pageCount){
        Page<ComplaintType> wherePage = new Page<>(page, pageCount);
        ComplaintType where = new ComplaintType();

        return   complaintTypeMapper.selectPage(wherePage, Wrappers.query(where));
    }

    @WebMethod
    @WebResult(name = "b")
    @Override
    public List<ComplaintType> queryType() {
        return complaintTypeMapper.selectList(null);
    }

    @WebMethod
    @WebResult(name = "c")
    @Override
    public int add(@WebParam(name = "complaintType")ComplaintType complaintType){
        return complaintTypeMapper.insert(complaintType);
    }

    @WebMethod
    @WebResult(name = "d")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return complaintTypeMapper.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int updateData(@WebParam(name = "complaintType")ComplaintType complaintType){
        return complaintTypeMapper.updateById(complaintType);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public ComplaintType findById(@WebParam(name = "id")Long id){
        return  complaintTypeMapper.selectById(id);
    }
}
