package com.yx.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.ClockinnewMapper;
import com.yx.model.Clockinnew;
import com.yx.service.IClockInNewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.Date;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 */
@AutoPublishWS(publishPath = "/clockinnew")
@WebService
@Service
public class ClockInNewServiceImpl implements IClockInNewService {

    @Autowired
    private ClockinnewMapper clockInNewDao;

    @WebMethod
    @WebResult(name = "a")
    @Override
    public PageInfo<Clockinnew> queryClockInAll(@WebParam(name = "pageNum")int pageNum, @WebParam(name = "pageSize")int pageSize, @WebParam(name = "clockinnew")Clockinnew clockinnew) {
        PageHelper.startPage(pageNum,pageSize);
        List<Clockinnew> list = clockInNewDao.queryClockInAll(clockinnew);
        return new PageInfo<>(list);
    }

    @WebMethod
    @WebResult(name = "b")
    @Override
    public Page<Clockinnew> findListByPage(@WebParam(name = "page")Integer page, @WebParam(name = "pageCount")Integer pageCount){
        Page<Clockinnew> wherePage = new Page<>(page, pageCount);
        Clockinnew where = new Clockinnew();

        return   clockInNewDao.selectPage(wherePage, Wrappers.query(where));
    }

    @WebMethod
    @WebResult(name = "c")
    @Override
    public int add(@WebParam(name = "clockinnew")Clockinnew clockinnew){
        return clockInNewDao.insert(clockinnew);
    }

    @WebMethod
    @WebResult(name = "d")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return clockInNewDao.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int updateData(@WebParam(name = "clockinnew")Clockinnew clockinnew){
        return clockInNewDao.updateById(clockinnew);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public Clockinnew findById(@WebParam(name = "id")Long id){
        return  clockInNewDao.selectById(id);
    }

    @WebMethod
    @WebResult(name = "g")
    @Override
    public Date queryCountByOwnId(@WebParam(name = "ownerId")Integer ownerId) {
        return clockInNewDao.queryCountByOwnId(ownerId);
    }
}
