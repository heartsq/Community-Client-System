package com.yx.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.RecordsMapper;
import com.yx.model.RecordVo;
import com.yx.model.Records;
import com.yx.service.IRecordsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kappy
 * @since 2020-10-28
 */
@AutoPublishWS(publishPath = "/records")
@WebService
@Service
public class RecordsServiceImpl implements IRecordsService {

    @Autowired
    private RecordsMapper recordsDao;

    @WebMethod
    @WebResult(name = "a")
    @Override
    public PageInfo<RecordVo> findRecordsAll(@WebParam(name = "page")int page, @WebParam(name = "limit")int limit, @WebParam(name = "recordVo")RecordVo recordVo) {
        PageHelper.startPage(page,limit);
        List<RecordVo> list=recordsDao.queryRecordsAll(recordVo);
        return new PageInfo<>(list);
    }

    @WebMethod
    @WebResult(name = "b")
    @Override
    public Records queryByHouIdAndTypeId(@WebParam(name = "houId")Integer houId, @WebParam(name = "typeId")Integer typeId) {
        return recordsDao.queryByHouIdAndTypeId(houId,typeId);
    }

    @WebMethod
    @WebResult(name = "c")
    @Override
    public int add(@WebParam(name = "building")Records building){
        return recordsDao.insert(building);
    }


    @WebMethod
    @WebResult(name = "d")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return recordsDao.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int updateData(@WebParam(name = "building")Records building){
        return recordsDao.updateById(building);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public Records findById(@WebParam(name = "id")Long id){
        return  recordsDao.selectById(id);
    }



}
