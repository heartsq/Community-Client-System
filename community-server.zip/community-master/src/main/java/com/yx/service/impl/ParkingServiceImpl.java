package com.yx.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.yx.annotation.AutoPublishWS;
import com.yx.dao.ParkingMapper;
import com.yx.model.Parking;
import com.yx.service.IParkingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kappy
 * @since 2020-10-28
 */
@AutoPublishWS(publishPath = "/parking")
@WebService
@Service
public class ParkingServiceImpl implements IParkingService {

    @Autowired
    private ParkingMapper parkingDao;

    @WebMethod
    @WebResult(name = "a")
    @Override
    public PageInfo<Parking> findParkAll(@WebParam(name = "page")int page, @WebParam(name = "pageSize")int pageSize, @WebParam(name = "numbers")String numbers) {
        PageHelper.startPage(page,pageSize);
        //查询的结果集
        List<Parking> list=parkingDao.queryParkAll(numbers);
        PageInfo<Parking> pageInfo=new PageInfo<>(list);
        return pageInfo;
    }

    @WebMethod
    @WebResult(name = "b")
    @Override
    public Page<Parking> findListByPage(@WebParam(name = "page")Integer page, @WebParam(name = "pageCount")Integer pageCount){
        Page<Parking> wherePage = new Page<>(page, pageCount);
        Parking where = new Parking();

        return   parkingDao.selectPage(wherePage, Wrappers.query(where));
    }

    @WebMethod
    @WebResult(name = "c")
    @Override
    public int add(@WebParam(name = "parking")Parking parking){
        return parkingDao.insert(parking);
    }

    @WebMethod
    @WebResult(name = "d")
    @Override
    public int delete(@WebParam(name = "id")Long id){
        return parkingDao.deleteById(id);
    }

    @WebMethod
    @WebResult(name = "e")
    @Override
    public int updateData(@WebParam(name = "parking")Parking parking){
        return parkingDao.updateById(parking);
    }

    @WebMethod
    @WebResult(name = "f")
    @Override
    public Parking findById(@WebParam(name = "id")Long id){
        return  parkingDao.selectById(id);
    }

    @WebMethod
    @WebResult(name = "g")
    @Override
    public List<Parking> queryParkingAll() {
        return null;
    }

    @WebMethod
    @WebResult(name = "h")
    @Override
    public List<Parking> queryParkingByStatus() {
        return parkingDao.queryParkAllByStatus();
    }


}
