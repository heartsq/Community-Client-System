package com.yx;


import com.yx.service.impl.*;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.lang.ClassNotFoundException;


public class ClientMain {
/*
	public PageInfo deserializeComplaint(byte[] bytes) throws IOException, ClassNotFoundException, java.io.IOException {
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
		ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream);
		PageInfo pageInfo = (PageInfo) objectInputStream.readObject();
		objectInputStream.close();
		return pageInfo;
	}*/
/*
	public String toString(PageInfo pi){
		return getCid() +"," + getCname() + ...; //你要输出的内容，不是字符串的话，加上一个转换。
	}*/

	public static void main(String[] args) throws Exception {
		//查询所有投诉
		/*
		DynamicClientFactory clientFactory = DynamicClientFactory.newInstance();
        Client client = clientFactory.createClient("http://localhost:8888/ws/complaint?wsdl");
        PageInfo<Complaint> pageInfo = new PageInfo<>();
        pageInfo=null;
        try
        {
            Object[] objects = client.invoke("findComplaintAll", new Object[]{page, limit, complaint});
            if(objects != null){
                pageInfo.setTotal((Long) objects[0]);  // 第一个元素为总记录数
                pageInfo.setList((List<Complaint>) objects[1]);  // 第二个元素为当前页的 Complaint 列表
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        JsonObject jsonObject = new JsonObject(0, "ok", pageInfo.getTotal(), pageInfo.getList());
		* */
		ComplaintServiceImplService c = new ComplaintServiceImplService();
		ComplaintServiceImpl cc = c.getComplaintServiceImplPort();
		Complaint t = new Complaint();
		Integer a = 1;
		Integer b = 15;

		PageInfo pi = cc.findComplaintAll(a, b, t);
		for (int i = 0; i < pi.getList().size(); i++) {
			Complaint temp = (Complaint) pi.getList().get(i);
			//获取temp
			if (temp.getId() != null) System.out.print(temp.getId().toString() + " ");
			if (temp.getClr() != null) System.out.print(temp.getClr().toString() + " ");
			if (temp.getComDate() != null) System.out.print(temp.getComDate().toString() + " ");
			if (temp.getComId() != null) System.out.print(temp.getComId().toString() + " ");
			if (temp.getHandleDate() != null) System.out.print(temp.getHandleDate().toString() + " ");
			//if(temp.getOwner()!=null)System.out.print(temp.getOwner().getUsername().toString()+" ");
			if (temp.getOwnerId() != null) System.out.print(temp.getOwnerId().toString() + " ");
			if (temp.getHandleDate() != null) System.out.print(temp.getHandleDate().toString() + " ");
			if (temp.getRemarks() != null) System.out.print(temp.getRemarks().toString() + " ");
			if (temp.getStatus() != null) System.out.print(temp.getStatus().toString() + " ");
			if (temp.getType() != null) System.out.print(temp.getType().getName().toString() + " ");
			System.out.println();
		}
	}
}

