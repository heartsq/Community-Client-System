
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>queryByHouIdAndTypeIdResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="queryByHouIdAndTypeIdResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="b" type="{http://impl.service.yx.com/}records" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queryByHouIdAndTypeIdResponse", propOrder = {
    "b"
})
public class QueryByHouIdAndTypeIdResponse {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected Records b;

    /**
     * ��ȡb���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Records }
     *     
     */
    public Records getB() {
        return b;
    }

    /**
     * ����b���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Records }
     *     
     */
    public void setB(Records value) {
        this.b = value;
    }

}
