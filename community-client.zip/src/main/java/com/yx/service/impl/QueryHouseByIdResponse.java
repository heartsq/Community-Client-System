
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>queryHouseByIdResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="queryHouseByIdResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="h" type="{http://impl.service.yx.com/}house" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queryHouseByIdResponse", propOrder = {
    "h"
})
public class QueryHouseByIdResponse {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected House h;

    /**
     * ��ȡh���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link House }
     *     
     */
    public House getH() {
        return h;
    }

    /**
     * ����h���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link House }
     *     
     */
    public void setH(House value) {
        this.h = value;
    }

}
