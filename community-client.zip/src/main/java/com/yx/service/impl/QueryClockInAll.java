
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>queryClockInAll complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="queryClockInAll">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="pageNum" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="pageSize" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="clockin" type="{http://impl.service.yx.com/}clockin" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queryClockInAll", propOrder = {
    "pageNum",
    "pageSize",
    "clockin"
})
public class QueryClockInAll {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected int pageNum;
    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected int pageSize;
    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected Clockin clockin;

    /**
     * ��ȡpageNum���Ե�ֵ��
     * 
     */
    public int getPageNum() {
        return pageNum;
    }

    /**
     * ����pageNum���Ե�ֵ��
     * 
     */
    public void setPageNum(int value) {
        this.pageNum = value;
    }

    /**
     * ��ȡpageSize���Ե�ֵ��
     * 
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * ����pageSize���Ե�ֵ��
     * 
     */
    public void setPageSize(int value) {
        this.pageSize = value;
    }

    /**
     * ��ȡclockin���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Clockin }
     *     
     */
    public Clockin getClockin() {
        return clockin;
    }

    /**
     * ����clockin���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Clockin }
     *     
     */
    public void setClockin(Clockin value) {
        this.clockin = value;
    }

}
