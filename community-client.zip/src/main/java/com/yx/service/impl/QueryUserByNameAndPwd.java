
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>queryUserByNameAndPwd complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="queryUserByNameAndPwd">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="userinfo" type="{http://impl.service.yx.com/}userinfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queryUserByNameAndPwd", propOrder = {
    "userinfo"
})
public class QueryUserByNameAndPwd {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected Userinfo userinfo;

    /**
     * ��ȡuserinfo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Userinfo }
     *     
     */
    public Userinfo getUserinfo() {
        return userinfo;
    }

    /**
     * ����userinfo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Userinfo }
     *     
     */
    public void setUserinfo(Userinfo value) {
        this.userinfo = value;
    }

}
