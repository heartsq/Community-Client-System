
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>findComplaintAll complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="findComplaintAll">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="page" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="pagesize" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="complaint" type="{http://impl.service.yx.com/}complaint" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "findComplaintAll", propOrder = {
    "page",
    "pagesize",
    "complaint"
})
public class FindComplaintAll {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected int page;
    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected int pagesize;
    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected Complaint complaint;

    /**
     * ��ȡpage���Ե�ֵ��
     * 
     */
    public int getPage() {
        return page;
    }

    /**
     * ����page���Ե�ֵ��
     * 
     */
    public void setPage(int value) {
        this.page = value;
    }

    /**
     * ��ȡpagesize���Ե�ֵ��
     * 
     */
    public int getPagesize() {
        return pagesize;
    }

    /**
     * ����pagesize���Ե�ֵ��
     * 
     */
    public void setPagesize(int value) {
        this.pagesize = value;
    }

    /**
     * ��ȡcomplaint���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Complaint }
     *     
     */
    public Complaint getComplaint() {
        return complaint;
    }

    /**
     * ����complaint���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Complaint }
     *     
     */
    public void setComplaint(Complaint value) {
        this.complaint = value;
    }

}
