
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>queryOwnerById complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="queryOwnerById">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="parseLong" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queryOwnerById", propOrder = {
    "parseLong"
})
public class QueryOwnerById {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected long parseLong;

    /**
     * ��ȡparseLong���Ե�ֵ��
     * 
     */
    public long getParseLong() {
        return parseLong;
    }

    /**
     * ����parseLong���Ե�ֵ��
     * 
     */
    public void setParseLong(long value) {
        this.parseLong = value;
    }

}
