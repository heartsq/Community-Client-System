
package com.yx.service.impl;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.yx.service.impl package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DeleteResponse_QNAME = new QName("http://impl.service.yx.com/", "deleteResponse");
    private final static QName _FindUserinfoAllResponse_QNAME = new QName("http://impl.service.yx.com/", "findUserinfoAllResponse");
    private final static QName _FindById_QNAME = new QName("http://impl.service.yx.com/", "findById");
    private final static QName _FindByIdResponse_QNAME = new QName("http://impl.service.yx.com/", "findByIdResponse");
    private final static QName _FindListByPage_QNAME = new QName("http://impl.service.yx.com/", "findListByPage");
    private final static QName _FindUserinfoAll_QNAME = new QName("http://impl.service.yx.com/", "findUserinfoAll");
    private final static QName _UpdateDataResponse_QNAME = new QName("http://impl.service.yx.com/", "updateDataResponse");
    private final static QName _QueryUserByNameAndPwd_QNAME = new QName("http://impl.service.yx.com/", "queryUserByNameAndPwd");
    private final static QName _AddResponse_QNAME = new QName("http://impl.service.yx.com/", "addResponse");
    private final static QName _UpdateData_QNAME = new QName("http://impl.service.yx.com/", "updateData");
    private final static QName _Add_QNAME = new QName("http://impl.service.yx.com/", "add");
    private final static QName _DeleteUserByUsername_QNAME = new QName("http://impl.service.yx.com/", "deleteUserByUsername");
    private final static QName _Delete_QNAME = new QName("http://impl.service.yx.com/", "delete");
    private final static QName _FindListByPageResponse_QNAME = new QName("http://impl.service.yx.com/", "findListByPageResponse");
    private final static QName _DeleteUserByUsernameResponse_QNAME = new QName("http://impl.service.yx.com/", "deleteUserByUsernameResponse");
    private final static QName _QueryUserByNameAndPwdResponse_QNAME = new QName("http://impl.service.yx.com/", "queryUserByNameAndPwdResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.yx.service.impl
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Add }
     * 
     */
    public Add createAdd() {
        return new Add();
    }

    /**
     * Create an instance of {@link DeleteUserByUsername }
     * 
     */
    public DeleteUserByUsername createDeleteUserByUsername() {
        return new DeleteUserByUsername();
    }

    /**
     * Create an instance of {@link QueryUserByNameAndPwd }
     * 
     */
    public QueryUserByNameAndPwd createQueryUserByNameAndPwd() {
        return new QueryUserByNameAndPwd();
    }

    /**
     * Create an instance of {@link AddResponse }
     * 
     */
    public AddResponse createAddResponse() {
        return new AddResponse();
    }

    /**
     * Create an instance of {@link UpdateData }
     * 
     */
    public UpdateData createUpdateData() {
        return new UpdateData();
    }

    /**
     * Create an instance of {@link DeleteUserByUsernameResponse }
     * 
     */
    public DeleteUserByUsernameResponse createDeleteUserByUsernameResponse() {
        return new DeleteUserByUsernameResponse();
    }

    /**
     * Create an instance of {@link QueryUserByNameAndPwdResponse }
     * 
     */
    public QueryUserByNameAndPwdResponse createQueryUserByNameAndPwdResponse() {
        return new QueryUserByNameAndPwdResponse();
    }

    /**
     * Create an instance of {@link Delete }
     * 
     */
    public Delete createDelete() {
        return new Delete();
    }

    /**
     * Create an instance of {@link FindListByPageResponse }
     * 
     */
    public FindListByPageResponse createFindListByPageResponse() {
        return new FindListByPageResponse();
    }

    /**
     * Create an instance of {@link FindListByPage }
     * 
     */
    public FindListByPage createFindListByPage() {
        return new FindListByPage();
    }

    /**
     * Create an instance of {@link FindUserinfoAll }
     * 
     */
    public FindUserinfoAll createFindUserinfoAll() {
        return new FindUserinfoAll();
    }

    /**
     * Create an instance of {@link DeleteResponse }
     * 
     */
    public DeleteResponse createDeleteResponse() {
        return new DeleteResponse();
    }

    /**
     * Create an instance of {@link FindUserinfoAllResponse }
     * 
     */
    public FindUserinfoAllResponse createFindUserinfoAllResponse() {
        return new FindUserinfoAllResponse();
    }

    /**
     * Create an instance of {@link FindById }
     * 
     */
    public FindById createFindById() {
        return new FindById();
    }

    /**
     * Create an instance of {@link FindByIdResponse }
     * 
     */
    public FindByIdResponse createFindByIdResponse() {
        return new FindByIdResponse();
    }

    /**
     * Create an instance of {@link UpdateDataResponse }
     * 
     */
    public UpdateDataResponse createUpdateDataResponse() {
        return new UpdateDataResponse();
    }

    /**
     * Create an instance of {@link OrderItem }
     * 
     */
    public OrderItem createOrderItem() {
        return new OrderItem();
    }

    /**
     * Create an instance of {@link PageInfo }
     * 
     */
    public PageInfo createPageInfo() {
        return new PageInfo();
    }

    /**
     * Create an instance of {@link PageSerializable }
     * 
     */
    public PageSerializable createPageSerializable() {
        return new PageSerializable();
    }

    /**
     * Create an instance of {@link Page }
     * 
     */
    public Page createPage() {
        return new Page();
    }

    /**
     * Create an instance of {@link Userinfo }
     * 
     */
    public Userinfo createUserinfo() {
        return new Userinfo();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "deleteResponse")
    public JAXBElement<DeleteResponse> createDeleteResponse(DeleteResponse value) {
        return new JAXBElement<DeleteResponse>(_DeleteResponse_QNAME, DeleteResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindUserinfoAllResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "findUserinfoAllResponse")
    public JAXBElement<FindUserinfoAllResponse> createFindUserinfoAllResponse(FindUserinfoAllResponse value) {
        return new JAXBElement<FindUserinfoAllResponse>(_FindUserinfoAllResponse_QNAME, FindUserinfoAllResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindById }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "findById")
    public JAXBElement<FindById> createFindById(FindById value) {
        return new JAXBElement<FindById>(_FindById_QNAME, FindById.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindByIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "findByIdResponse")
    public JAXBElement<FindByIdResponse> createFindByIdResponse(FindByIdResponse value) {
        return new JAXBElement<FindByIdResponse>(_FindByIdResponse_QNAME, FindByIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindListByPage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "findListByPage")
    public JAXBElement<FindListByPage> createFindListByPage(FindListByPage value) {
        return new JAXBElement<FindListByPage>(_FindListByPage_QNAME, FindListByPage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindUserinfoAll }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "findUserinfoAll")
    public JAXBElement<FindUserinfoAll> createFindUserinfoAll(FindUserinfoAll value) {
        return new JAXBElement<FindUserinfoAll>(_FindUserinfoAll_QNAME, FindUserinfoAll.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateDataResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "updateDataResponse")
    public JAXBElement<UpdateDataResponse> createUpdateDataResponse(UpdateDataResponse value) {
        return new JAXBElement<UpdateDataResponse>(_UpdateDataResponse_QNAME, UpdateDataResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryUserByNameAndPwd }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "queryUserByNameAndPwd")
    public JAXBElement<QueryUserByNameAndPwd> createQueryUserByNameAndPwd(QueryUserByNameAndPwd value) {
        return new JAXBElement<QueryUserByNameAndPwd>(_QueryUserByNameAndPwd_QNAME, QueryUserByNameAndPwd.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "addResponse")
    public JAXBElement<AddResponse> createAddResponse(AddResponse value) {
        return new JAXBElement<AddResponse>(_AddResponse_QNAME, AddResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateData }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "updateData")
    public JAXBElement<UpdateData> createUpdateData(UpdateData value) {
        return new JAXBElement<UpdateData>(_UpdateData_QNAME, UpdateData.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Add }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "add")
    public JAXBElement<Add> createAdd(Add value) {
        return new JAXBElement<Add>(_Add_QNAME, Add.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteUserByUsername }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "deleteUserByUsername")
    public JAXBElement<DeleteUserByUsername> createDeleteUserByUsername(DeleteUserByUsername value) {
        return new JAXBElement<DeleteUserByUsername>(_DeleteUserByUsername_QNAME, DeleteUserByUsername.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Delete }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "delete")
    public JAXBElement<Delete> createDelete(Delete value) {
        return new JAXBElement<Delete>(_Delete_QNAME, Delete.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindListByPageResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "findListByPageResponse")
    public JAXBElement<FindListByPageResponse> createFindListByPageResponse(FindListByPageResponse value) {
        return new JAXBElement<FindListByPageResponse>(_FindListByPageResponse_QNAME, FindListByPageResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteUserByUsernameResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "deleteUserByUsernameResponse")
    public JAXBElement<DeleteUserByUsernameResponse> createDeleteUserByUsernameResponse(DeleteUserByUsernameResponse value) {
        return new JAXBElement<DeleteUserByUsernameResponse>(_DeleteUserByUsernameResponse_QNAME, DeleteUserByUsernameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryUserByNameAndPwdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://impl.service.yx.com/", name = "queryUserByNameAndPwdResponse")
    public JAXBElement<QueryUserByNameAndPwdResponse> createQueryUserByNameAndPwdResponse(QueryUserByNameAndPwdResponse value) {
        return new JAXBElement<QueryUserByNameAndPwdResponse>(_QueryUserByNameAndPwdResponse_QNAME, QueryUserByNameAndPwdResponse.class, null, value);
    }

}
