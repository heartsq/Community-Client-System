
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>findPropertyInfoAll complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="findPropertyInfoAll">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="page" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="pagesize" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="propertyInfo" type="{http://impl.service.yx.com/}propertyInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "findPropertyInfoAll", propOrder = {
    "page",
    "pagesize",
    "propertyInfo"
})
public class FindPropertyInfoAll {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected int page;
    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected int pagesize;
    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected PropertyInfo propertyInfo;

    /**
     * ��ȡpage���Ե�ֵ��
     * 
     */
    public int getPage() {
        return page;
    }

    /**
     * ����page���Ե�ֵ��
     * 
     */
    public void setPage(int value) {
        this.page = value;
    }

    /**
     * ��ȡpagesize���Ե�ֵ��
     * 
     */
    public int getPagesize() {
        return pagesize;
    }

    /**
     * ����pagesize���Ե�ֵ��
     * 
     */
    public void setPagesize(int value) {
        this.pagesize = value;
    }

    /**
     * ��ȡpropertyInfo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link PropertyInfo }
     *     
     */
    public PropertyInfo getPropertyInfo() {
        return propertyInfo;
    }

    /**
     * ����propertyInfo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link PropertyInfo }
     *     
     */
    public void setPropertyInfo(PropertyInfo value) {
        this.propertyInfo = value;
    }

}
