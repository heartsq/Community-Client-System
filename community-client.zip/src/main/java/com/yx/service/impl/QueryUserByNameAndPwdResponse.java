
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>queryUserByNameAndPwdResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="queryUserByNameAndPwdResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="g" type="{http://impl.service.yx.com/}userinfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queryUserByNameAndPwdResponse", propOrder = {
    "g"
})
public class QueryUserByNameAndPwdResponse {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected Userinfo g;

    /**
     * ��ȡg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Userinfo }
     *     
     */
    public Userinfo getG() {
        return g;
    }

    /**
     * ����g���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Userinfo }
     *     
     */
    public void setG(Userinfo value) {
        this.g = value;
    }

}
