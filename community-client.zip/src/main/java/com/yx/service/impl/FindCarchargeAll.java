
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>findCarchargeAll complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="findCarchargeAll">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="page" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="pagesize" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="carcharge" type="{http://impl.service.yx.com/}carcharge" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "findCarchargeAll", propOrder = {
    "page",
    "pagesize",
    "carcharge"
})
public class FindCarchargeAll {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected int page;
    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected int pagesize;
    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected Carcharge carcharge;

    /**
     * ��ȡpage���Ե�ֵ��
     * 
     */
    public int getPage() {
        return page;
    }

    /**
     * ����page���Ե�ֵ��
     * 
     */
    public void setPage(int value) {
        this.page = value;
    }

    /**
     * ��ȡpagesize���Ե�ֵ��
     * 
     */
    public int getPagesize() {
        return pagesize;
    }

    /**
     * ����pagesize���Ե�ֵ��
     * 
     */
    public void setPagesize(int value) {
        this.pagesize = value;
    }

    /**
     * ��ȡcarcharge���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Carcharge }
     *     
     */
    public Carcharge getCarcharge() {
        return carcharge;
    }

    /**
     * ����carcharge���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Carcharge }
     *     
     */
    public void setCarcharge(Carcharge value) {
        this.carcharge = value;
    }

}
