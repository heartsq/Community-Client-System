
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>queryOwnerByNameResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="queryOwnerByNameResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="c" type="{http://impl.service.yx.com/}owner" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queryOwnerByNameResponse", propOrder = {
    "c"
})
public class QueryOwnerByNameResponse {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected Owner c;

    /**
     * ��ȡc���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Owner }
     *     
     */
    public Owner getC() {
        return c;
    }

    /**
     * ����c���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Owner }
     *     
     */
    public void setC(Owner value) {
        this.c = value;
    }

}
