
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>queryOwnerByIdResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="queryOwnerByIdResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="i" type="{http://impl.service.yx.com/}owner" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queryOwnerByIdResponse", propOrder = {
    "i"
})
public class QueryOwnerByIdResponse {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected Owner i;

    /**
     * ��ȡi���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Owner }
     *     
     */
    public Owner getI() {
        return i;
    }

    /**
     * ����i���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Owner }
     *     
     */
    public void setI(Owner value) {
        this.i = value;
    }

}
