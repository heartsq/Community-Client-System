
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>findByIdResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="findByIdResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="f" type="{http://impl.service.yx.com/}userinfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "findByIdResponse", propOrder = {
    "f"
})
public class FindByIdResponse {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected Userinfo f;

    /**
     * ��ȡf���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Userinfo }
     *     
     */
    public Userinfo getF() {
        return f;
    }

    /**
     * ����f���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Userinfo }
     *     
     */
    public void setF(Userinfo value) {
        this.f = value;
    }

}
