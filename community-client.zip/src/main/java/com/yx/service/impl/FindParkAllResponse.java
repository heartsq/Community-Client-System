
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>findParkAllResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="findParkAllResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="a" type="{http://impl.service.yx.com/}pageInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "findParkAllResponse", propOrder = {
    "a"
})
public class FindParkAllResponse {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected PageInfo a;

    /**
     * ��ȡa���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link PageInfo }
     *     
     */
    public PageInfo getA() {
        return a;
    }

    /**
     * ����a���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link PageInfo }
     *     
     */
    public void setA(PageInfo value) {
        this.a = value;
    }

}
