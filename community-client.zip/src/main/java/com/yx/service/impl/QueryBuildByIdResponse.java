
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>queryBuildByIdResponse complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="queryBuildByIdResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="g" type="{http://impl.service.yx.com/}building" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "queryBuildByIdResponse", propOrder = {
    "g"
})
public class QueryBuildByIdResponse {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected Building g;

    /**
     * ��ȡg���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Building }
     *     
     */
    public Building getG() {
        return g;
    }

    /**
     * ����g���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Building }
     *     
     */
    public void setG(Building value) {
        this.g = value;
    }

}
