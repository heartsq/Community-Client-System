
package com.yx.service.impl;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>pageInfo complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="pageInfo">
 *   &lt;complexContent>
 *     &lt;extension base="{http://impl.service.yx.com/}pageSerializable">
 *       &lt;sequence>
 *         &lt;element name="endRow" type="{http://www.w3.org/2001/XMLSchema}int" form="unqualified"/>
 *         &lt;element name="hasNextPage" type="{http://www.w3.org/2001/XMLSchema}boolean" form="unqualified"/>
 *         &lt;element name="hasPreviousPage" type="{http://www.w3.org/2001/XMLSchema}boolean" form="unqualified"/>
 *         &lt;element name="isFirstPage" type="{http://www.w3.org/2001/XMLSchema}boolean" form="unqualified"/>
 *         &lt;element name="isLastPage" type="{http://www.w3.org/2001/XMLSchema}boolean" form="unqualified"/>
 *         &lt;element name="navigateFirstPage" type="{http://www.w3.org/2001/XMLSchema}int" form="unqualified"/>
 *         &lt;element name="navigateLastPage" type="{http://www.w3.org/2001/XMLSchema}int" form="unqualified"/>
 *         &lt;element name="navigatePages" type="{http://www.w3.org/2001/XMLSchema}int" form="unqualified"/>
 *         &lt;element name="navigatepageNums" type="{http://www.w3.org/2001/XMLSchema}int" maxOccurs="unbounded" minOccurs="0" form="unqualified"/>
 *         &lt;element name="nextPage" type="{http://www.w3.org/2001/XMLSchema}int" form="unqualified"/>
 *         &lt;element name="pageNum" type="{http://www.w3.org/2001/XMLSchema}int" form="unqualified"/>
 *         &lt;element name="pageSize" type="{http://www.w3.org/2001/XMLSchema}int" form="unqualified"/>
 *         &lt;element name="pages" type="{http://www.w3.org/2001/XMLSchema}int" form="unqualified"/>
 *         &lt;element name="prePage" type="{http://www.w3.org/2001/XMLSchema}int" form="unqualified"/>
 *         &lt;element name="size" type="{http://www.w3.org/2001/XMLSchema}int" form="unqualified"/>
 *         &lt;element name="startRow" type="{http://www.w3.org/2001/XMLSchema}int" form="unqualified"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "pageInfo", propOrder = {
    "endRow",
    "hasNextPage",
    "hasPreviousPage",
    "isFirstPage",
    "isLastPage",
    "navigateFirstPage",
    "navigateLastPage",
    "navigatePages",
    "navigatepageNums",
    "nextPage",
    "pageNum",
    "pageSize",
    "pages",
    "prePage",
    "size",
    "startRow"
})
public class PageInfo
    extends PageSerializable
{

    protected int endRow;
    protected boolean hasNextPage;
    protected boolean hasPreviousPage;
    protected boolean isFirstPage;
    protected boolean isLastPage;
    protected int navigateFirstPage;
    protected int navigateLastPage;
    protected int navigatePages;
    @XmlElement(nillable = true)
    protected List<Integer> navigatepageNums;
    protected int nextPage;
    protected int pageNum;
    protected int pageSize;
    protected int pages;
    protected int prePage;
    protected int size;
    protected int startRow;

    /**
     * ��ȡendRow���Ե�ֵ��
     * 
     */
    public int getEndRow() {
        return endRow;
    }

    /**
     * ����endRow���Ե�ֵ��
     * 
     */
    public void setEndRow(int value) {
        this.endRow = value;
    }

    /**
     * ��ȡhasNextPage���Ե�ֵ��
     * 
     */
    public boolean isHasNextPage() {
        return hasNextPage;
    }

    /**
     * ����hasNextPage���Ե�ֵ��
     * 
     */
    public void setHasNextPage(boolean value) {
        this.hasNextPage = value;
    }

    /**
     * ��ȡhasPreviousPage���Ե�ֵ��
     * 
     */
    public boolean isHasPreviousPage() {
        return hasPreviousPage;
    }

    /**
     * ����hasPreviousPage���Ե�ֵ��
     * 
     */
    public void setHasPreviousPage(boolean value) {
        this.hasPreviousPage = value;
    }

    /**
     * ��ȡisFirstPage���Ե�ֵ��
     * 
     */
    public boolean isIsFirstPage() {
        return isFirstPage;
    }

    /**
     * ����isFirstPage���Ե�ֵ��
     * 
     */
    public void setIsFirstPage(boolean value) {
        this.isFirstPage = value;
    }

    /**
     * ��ȡisLastPage���Ե�ֵ��
     * 
     */
    public boolean isIsLastPage() {
        return isLastPage;
    }

    /**
     * ����isLastPage���Ե�ֵ��
     * 
     */
    public void setIsLastPage(boolean value) {
        this.isLastPage = value;
    }

    /**
     * ��ȡnavigateFirstPage���Ե�ֵ��
     * 
     */
    public int getNavigateFirstPage() {
        return navigateFirstPage;
    }

    /**
     * ����navigateFirstPage���Ե�ֵ��
     * 
     */
    public void setNavigateFirstPage(int value) {
        this.navigateFirstPage = value;
    }

    /**
     * ��ȡnavigateLastPage���Ե�ֵ��
     * 
     */
    public int getNavigateLastPage() {
        return navigateLastPage;
    }

    /**
     * ����navigateLastPage���Ե�ֵ��
     * 
     */
    public void setNavigateLastPage(int value) {
        this.navigateLastPage = value;
    }

    /**
     * ��ȡnavigatePages���Ե�ֵ��
     * 
     */
    public int getNavigatePages() {
        return navigatePages;
    }

    /**
     * ����navigatePages���Ե�ֵ��
     * 
     */
    public void setNavigatePages(int value) {
        this.navigatePages = value;
    }

    /**
     * Gets the value of the navigatepageNums property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the navigatepageNums property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNavigatepageNums().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Integer }
     * 
     * 
     */
    public List<Integer> getNavigatepageNums() {
        if (navigatepageNums == null) {
            navigatepageNums = new ArrayList<Integer>();
        }
        return this.navigatepageNums;
    }

    /**
     * ��ȡnextPage���Ե�ֵ��
     * 
     */
    public int getNextPage() {
        return nextPage;
    }

    /**
     * ����nextPage���Ե�ֵ��
     * 
     */
    public void setNextPage(int value) {
        this.nextPage = value;
    }

    /**
     * ��ȡpageNum���Ե�ֵ��
     * 
     */
    public int getPageNum() {
        return pageNum;
    }

    /**
     * ����pageNum���Ե�ֵ��
     * 
     */
    public void setPageNum(int value) {
        this.pageNum = value;
    }

    /**
     * ��ȡpageSize���Ե�ֵ��
     * 
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * ����pageSize���Ե�ֵ��
     * 
     */
    public void setPageSize(int value) {
        this.pageSize = value;
    }

    /**
     * ��ȡpages���Ե�ֵ��
     * 
     */
    public int getPages() {
        return pages;
    }

    /**
     * ����pages���Ե�ֵ��
     * 
     */
    public void setPages(int value) {
        this.pages = value;
    }

    /**
     * ��ȡprePage���Ե�ֵ��
     * 
     */
    public int getPrePage() {
        return prePage;
    }

    /**
     * ����prePage���Ե�ֵ��
     * 
     */
    public void setPrePage(int value) {
        this.prePage = value;
    }

    /**
     * ��ȡsize���Ե�ֵ��
     * 
     */
    public int getSize() {
        return size;
    }

    /**
     * ����size���Ե�ֵ��
     * 
     */
    public void setSize(int value) {
        this.size = value;
    }

    /**
     * ��ȡstartRow���Ե�ֵ��
     * 
     */
    public int getStartRow() {
        return startRow;
    }

    /**
     * ����startRow���Ե�ֵ��
     * 
     */
    public void setStartRow(int value) {
        this.startRow = value;
    }

}
