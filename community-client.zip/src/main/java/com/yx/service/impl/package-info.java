@javax.xml.bind.annotation.XmlSchema(namespace = "http://impl.service.yx.com/")
package com.yx.service.impl;
