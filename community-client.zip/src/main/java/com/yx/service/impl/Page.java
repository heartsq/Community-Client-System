
package com.yx.service.impl;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>page complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="page">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="countId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="unqualified"/>
 *         &lt;element name="current" type="{http://www.w3.org/2001/XMLSchema}long" form="unqualified"/>
 *         &lt;element name="hitCount" type="{http://www.w3.org/2001/XMLSchema}boolean" form="unqualified"/>
 *         &lt;element name="maxLimit" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0" form="unqualified"/>
 *         &lt;element name="optimizeCountSql" type="{http://www.w3.org/2001/XMLSchema}boolean" form="unqualified"/>
 *         &lt;element name="orders" type="{http://impl.service.yx.com/}orderItem" maxOccurs="unbounded" minOccurs="0" form="unqualified"/>
 *         &lt;element name="records" type="{http://www.w3.org/2001/XMLSchema}anyType" maxOccurs="unbounded" minOccurs="0" form="unqualified"/>
 *         &lt;element name="searchCount" type="{http://www.w3.org/2001/XMLSchema}boolean" form="unqualified"/>
 *         &lt;element name="size" type="{http://www.w3.org/2001/XMLSchema}long" form="unqualified"/>
 *         &lt;element name="total" type="{http://www.w3.org/2001/XMLSchema}long" form="unqualified"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "page", propOrder = {
    "countId",
    "current",
    "hitCount",
    "maxLimit",
    "optimizeCountSql",
    "orders",
    "records",
    "searchCount",
    "size",
    "total"
})
public class Page {

    protected String countId;
    protected long current;
    protected boolean hitCount;
    protected Long maxLimit;
    protected boolean optimizeCountSql;
    @XmlElement(nillable = true)
    protected List<OrderItem> orders;
    @XmlElement(nillable = true)
    protected List<Object> records;
    protected boolean searchCount;
    protected long size;
    protected long total;

    /**
     * ��ȡcountId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCountId() {
        return countId;
    }

    /**
     * ����countId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCountId(String value) {
        this.countId = value;
    }

    /**
     * ��ȡcurrent���Ե�ֵ��
     * 
     */
    public long getCurrent() {
        return current;
    }

    /**
     * ����current���Ե�ֵ��
     * 
     */
    public void setCurrent(long value) {
        this.current = value;
    }

    /**
     * ��ȡhitCount���Ե�ֵ��
     * 
     */
    public boolean isHitCount() {
        return hitCount;
    }

    /**
     * ����hitCount���Ե�ֵ��
     * 
     */
    public void setHitCount(boolean value) {
        this.hitCount = value;
    }

    /**
     * ��ȡmaxLimit���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getMaxLimit() {
        return maxLimit;
    }

    /**
     * ����maxLimit���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setMaxLimit(Long value) {
        this.maxLimit = value;
    }

    /**
     * ��ȡoptimizeCountSql���Ե�ֵ��
     * 
     */
    public boolean isOptimizeCountSql() {
        return optimizeCountSql;
    }

    /**
     * ����optimizeCountSql���Ե�ֵ��
     * 
     */
    public void setOptimizeCountSql(boolean value) {
        this.optimizeCountSql = value;
    }

    /**
     * Gets the value of the orders property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the orders property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOrders().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OrderItem }
     * 
     * 
     */
    public List<OrderItem> getOrders() {
        if (orders == null) {
            orders = new ArrayList<OrderItem>();
        }
        return this.orders;
    }

    /**
     * Gets the value of the records property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the records property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRecords().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Object }
     * 
     * 
     */
    public List<Object> getRecords() {
        if (records == null) {
            records = new ArrayList<Object>();
        }
        return this.records;
    }

    /**
     * ��ȡsearchCount���Ե�ֵ��
     * 
     */
    public boolean isSearchCount() {
        return searchCount;
    }

    /**
     * ����searchCount���Ե�ֵ��
     * 
     */
    public void setSearchCount(boolean value) {
        this.searchCount = value;
    }

    /**
     * ��ȡsize���Ե�ֵ��
     * 
     */
    public long getSize() {
        return size;
    }

    /**
     * ����size���Ե�ֵ��
     * 
     */
    public void setSize(long value) {
        this.size = value;
    }

    /**
     * ��ȡtotal���Ե�ֵ��
     * 
     */
    public long getTotal() {
        return total;
    }

    /**
     * ����total���Ե�ֵ��
     * 
     */
    public void setTotal(long value) {
        this.total = value;
    }

}
