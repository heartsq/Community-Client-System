
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>clockin complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="clockin">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="building" type="{http://impl.service.yx.com/}building" minOccurs="0" form="unqualified"/>
 *         &lt;element name="buildingId" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0" form="unqualified"/>
 *         &lt;element name="clockInTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0" form="unqualified"/>
 *         &lt;element name="house" type="{http://impl.service.yx.com/}house" minOccurs="0" form="unqualified"/>
 *         &lt;element name="houseId" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0" form="unqualified"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0" form="unqualified"/>
 *         &lt;element name="owner" type="{http://impl.service.yx.com/}owner" minOccurs="0" form="unqualified"/>
 *         &lt;element name="ownerId" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0" form="unqualified"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "clockin", propOrder = {
    "building",
    "buildingId",
    "clockInTime",
    "house",
    "houseId",
    "id",
    "owner",
    "ownerId"
})
public class Clockin {

    protected Building building;
    protected Integer buildingId;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar clockInTime;
    protected House house;
    protected Integer houseId;
    protected Integer id;
    protected Owner owner;
    protected Integer ownerId;

    /**
     * ��ȡbuilding���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Building }
     *     
     */
    public Building getBuilding() {
        return building;
    }

    /**
     * ����building���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Building }
     *     
     */
    public void setBuilding(Building value) {
        this.building = value;
    }

    /**
     * ��ȡbuildingId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getBuildingId() {
        return buildingId;
    }

    /**
     * ����buildingId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBuildingId(Integer value) {
        this.buildingId = value;
    }

    /**
     * ��ȡclockInTime���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getClockInTime() {
        return clockInTime;
    }

    /**
     * ����clockInTime���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setClockInTime(XMLGregorianCalendar value) {
        this.clockInTime = value;
    }

    /**
     * ��ȡhouse���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link House }
     *     
     */
    public House getHouse() {
        return house;
    }

    /**
     * ����house���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link House }
     *     
     */
    public void setHouse(House value) {
        this.house = value;
    }

    /**
     * ��ȡhouseId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getHouseId() {
        return houseId;
    }

    /**
     * ����houseId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setHouseId(Integer value) {
        this.houseId = value;
    }

    /**
     * ��ȡid���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getId() {
        return id;
    }

    /**
     * ����id���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setId(Integer value) {
        this.id = value;
    }

    /**
     * ��ȡowner���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Owner }
     *     
     */
    public Owner getOwner() {
        return owner;
    }

    /**
     * ����owner���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Owner }
     *     
     */
    public void setOwner(Owner value) {
        this.owner = value;
    }

    /**
     * ��ȡownerId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getOwnerId() {
        return ownerId;
    }

    /**
     * ����ownerId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setOwnerId(Integer value) {
        this.ownerId = value;
    }

}
