
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>findRepairAll complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="findRepairAll">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="page" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="pagesize" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="repair" type="{http://impl.service.yx.com/}repair" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "findRepairAll", propOrder = {
    "page",
    "pagesize",
    "repair"
})
public class FindRepairAll {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected int page;
    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected int pagesize;
    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected Repair repair;

    /**
     * ��ȡpage���Ե�ֵ��
     * 
     */
    public int getPage() {
        return page;
    }

    /**
     * ����page���Ե�ֵ��
     * 
     */
    public void setPage(int value) {
        this.page = value;
    }

    /**
     * ��ȡpagesize���Ե�ֵ��
     * 
     */
    public int getPagesize() {
        return pagesize;
    }

    /**
     * ����pagesize���Ե�ֵ��
     * 
     */
    public void setPagesize(int value) {
        this.pagesize = value;
    }

    /**
     * ��ȡrepair���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link Repair }
     *     
     */
    public Repair getRepair() {
        return repair;
    }

    /**
     * ����repair���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link Repair }
     *     
     */
    public void setRepair(Repair value) {
        this.repair = value;
    }

}
