
package com.yx.service.impl;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>findRecordsAll complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="findRecordsAll">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="page" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="limit" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="recordVo" type="{http://impl.service.yx.com/}recordVo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "findRecordsAll", propOrder = {
    "page",
    "limit",
    "recordVo"
})
public class FindRecordsAll {

    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected int page;
    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected int limit;
    @XmlElement(namespace = "http://impl.service.yx.com/")
    protected RecordVo recordVo;

    /**
     * ��ȡpage���Ե�ֵ��
     * 
     */
    public int getPage() {
        return page;
    }

    /**
     * ����page���Ե�ֵ��
     * 
     */
    public void setPage(int value) {
        this.page = value;
    }

    /**
     * ��ȡlimit���Ե�ֵ��
     * 
     */
    public int getLimit() {
        return limit;
    }

    /**
     * ����limit���Ե�ֵ��
     * 
     */
    public void setLimit(int value) {
        this.limit = value;
    }

    /**
     * ��ȡrecordVo���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link RecordVo }
     *     
     */
    public RecordVo getRecordVo() {
        return recordVo;
    }

    /**
     * ����recordVo���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link RecordVo }
     *     
     */
    public void setRecordVo(RecordVo value) {
        this.recordVo = value;
    }

}
